#The local daemon of bitcoin network(bitcoind must be running in )
RPC_URL     = "http://127.0.0.1:18332"
RPC_USER    = "nirojpokhrel"
RPC_PASS    = "niroj123"
PORT_ADDRESS = '/dev/ttyACM0' #Needs changing ?????
SUBMIT_DATA = True
DEBUG_LOCAL_DATA = False
TARGET_REDUCE = "00000000"
PUBLIC_KEY = "mxWqotbFkgBNAziCFHTUpkws8YHootQHD8" #PUBLICKEY FOR account nirojpokhrel
COINBASE_MSG = "Any message you want to put in coinbase transactions!!!"